# 143B-File-System
Project 1 for CS 143B class.

## Requirements
- at least cmake 3.20.0
- g++

## How to Run
If on Linux machine:
```{bash}
cmake --preset linux
```

If on Windows machine:
```{bash}
cmake --preset windows
```

To build the binary, enter:
```{bash}
cmake --build build --target main
```

To execute the shell, enter:
```{bash}
./build/main
```

In order to test against the released results:
```{bash}
./build/main < FS-input-1.txt > output.txt
```
